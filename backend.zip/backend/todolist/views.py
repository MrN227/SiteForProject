from django.shortcuts import render
from rest_framework import viewsets
from todolist.serializers import TodoSerializer
from todolist.models import DataTodo

# Create your views here.

class TodoView(viewsets.ModelViewSet):
    serializer_class = TodoSerializer
    queryset = DataTodo.objects.all()