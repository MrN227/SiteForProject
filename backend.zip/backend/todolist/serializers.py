from rest_framework import serializers
from todolist.models import DataTodo

class TodoSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataTodo
        fields = ('id', 'title', 'description', 'completed')