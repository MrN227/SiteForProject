from django.contrib import admin
from todolist.models import DataTodo

class TodoAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'completed')

# Register your models here.

admin.site.register(DataTodo, TodoAdmin)