from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.views.generic import TemplateView

from .forms import *
from .models import *

def index(request):
	return render(request, 'Gum/index.html', {'title':'Home'})


def log(request):
	context = {}
	if request.method == 'POST':
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			return redirect("profile")
		else:
			context['error'] = "Логин или пароль неправильные"
	return render(request, 'Gum/login.html', context)

def registr(request):
	if request.method == "POST":
		name = request.POST.get('name')
		mail = request.POST.get('email')
		passwd = request.POST.get('pswd')
		passwd2 = request.POST.get('pswd2')

		output = '<h2>User</h2><h3>Name - {0}, Mail@ - {1}, Password - {2}</h3>'\
					.format(name, mail, passwd)
		if passwd == passwd2:
			User.objects.create_user(name, mail, passwd)
			return redirect(reverse("home"))
	else:
		userform = UserForm()
		return render(request, 'Gum/registr.html', {'title':'Reg', 'form':userform})

class ProfilePage(TemplateView):
    template_name = "Gum/profile.html"