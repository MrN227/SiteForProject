from django import forms

class UserForm(forms.Form):
	pswd = forms.CharField(max_length = 20, widget = forms.PasswordInput(), label = 'Your password')
	pswd2 = forms.CharField(max_length = 20, widget = forms.PasswordInput(), label = 'Repite your password')
	name = forms.CharField(max_length = 255, label = 'Your name')
	email = forms.EmailField(label = "Your email")
	
	field_order = ['name', 'mobile', 'email', 'pswd', 'pswd2']

class Log(forms.Form):
	name = forms.CharField(max_length = 20)
	paswd = forms.CharField(max_length = 20, widget = forms.PasswordInput())


