from django.contrib import admin
from django.urls import path, re_path
from django.views.generic import TemplateView

from Gum.views import *

urlpatterns = [
    path('', index, name = 'home'),
    path('login/', log, name = 'log'),
    path('registr', registr, name = 'registr'),
    path('accounts/profile/', ProfilePage.as_view(), name="profile"),
]
